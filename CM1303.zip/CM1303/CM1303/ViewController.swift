//
//  ViewController.swift
//  CM1303
//
//  Created by 2020-2 on 13/03/20.
//  Copyright © 2020 UNAM. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    //@IBAction override func unwindToGreen(unwindSegue: UIStoryboardUnwindSegue){
    

    //}
   // override func prepare(for segue: UIStoryboardUnwindSegueSource, sender: Any?){
      //  segue.destination.navigationItem.title = textField.text
    //}
}

